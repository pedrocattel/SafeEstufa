// Pedro Lopes Marin Cattel – 15.01288-3
// Thomaz Erlach Gomes -15.03671-5
// Victor Xavier de Melo – 15.01027-9

#include "mbed.h"
#include "MMA7660.h"
#include "MFRC522.h"
#include "BME280.h"
#include "Adafruit_SSD1306.h"

#include <string>

// ------------- Defines ---------------

// Acelerometro
#define AC_SDA p28
#define AC_SCL p27
#define LED_MOVED LED1

// Speaker
#define SPEAKER p26

// Bluetooth
#define BT_TX p9
#define BT_RX p10

// RFID
#define RFID_MOSI p11
#define RFID_MISO p12
#define RFID_CLK p13
#define RFID_CS p14
#define RFID_RST p8
#define LED_VERIFICA LED2

// Sensor Pressao e Temperatura (BME)
#define BME_SDA p28
#define BME_SCL p27

// Display OLED
#define DISPLAY_MOSI p5
#define DISPLAY_CLK p7
#define DISPLAY_DC p25
#define DISPLAY_RST p24
#define DISPLAY_CS p23

// Sensor Umidade
#define UMID p15

// LDR
#define LDR p16

#define LED_LUZ p17

// Bomba
#define BOMBA p21

// ------------- Variaveis --------------

// Acelerometro MMA(SDA,SCL)
MMA7660 MMA(AC_SDA, AC_SCL);
DigitalOut move(LED_MOVED);

// Speaker
PwmOut spkr(SPEAKER);

// Bluetooth TX RX
Serial bt(BT_TX, BT_RX);

// RFID RfChip(SPI_MOSI, SPI_MISO, SPI_SCLK, SPI_CS, MF_RESET);
MFRC522 RfChip(RFID_MOSI, RFID_MISO, RFID_CLK, RFID_CS, RFID_RST);
DigitalOut verifica(LED_VERIFICA);

// Sensor Temperatura e Pressao BME(sda, scl) 
BME280 sensorTemp(BME_SDA, BME_SCL);
 
// Display
// an SPI sub-class that provides a constructed default
class SPIPreInit : public SPI
{
public:
    SPIPreInit(PinName mosi, PinName miso, PinName clk) : SPI(mosi,miso,clk)
    {
        format(8,3);
        frequency(2000000);
    };
};
 
// SPI(MOSI, MISO, CLK)
SPIPreInit gSpi(DISPLAY_MOSI, NC, DISPLAY_CLK);
// Adafruit(SPI, DC, RESET, CS)
Adafruit_SSD1306_Spi gOled1(gSpi, DISPLAY_DC, DISPLAY_RST, DISPLAY_CS);

// Sensor umidade
AnalogIn umid(UMID);

// LDR
AnalogIn ldr(LDR);

// Luz
DigitalOut luz(LED_LUZ);

int auth;
unsigned char key;
char senha[10] = "senha";

PwmOut bomba(BOMBA);

// ------------- Funções ---------------

// Speaker faz um toque
void Toque() {
    for (float i=2000.0; i<3000.0; i+=100) {
        spkr.period(1.0/i);
        spkr=0.5;
        wait(0.1);
    }
    spkr=0.0;
}

// Verifica se a estufa esta em movimento
void verificaPos() {
    if ((-0.15f > MMA.x()) || (0.15f < MMA.x()) || (-0.15f > MMA.y()) || (0.15f < MMA.y()) || (MMA.z() < 0.8f)) {
        move = 1;
        bt.printf("Estufa em movimento!!\n\r");
        Toque();
    }
}

// Verifica se a planta precisa de mais luz
void verificaLuz() {
    if ((float)ldr < 0.5f) {
        luz = 1;    
    } else {
        luz = 0;    
    }
}

// Verifica se precisa regar
void verificaAgua() {
    if ((float)umid > 0.8f) {
        bt.printf("\n\rRegando...\n\r");
        bomba.write(1.0f);
        wait_ms(500);
        bomba.write(0.0f);
    }    
}

// Exibe as informacoes no display
void MostrarOled(){
    gOled1.setTextCursor(0,0);
    gOled1.printf("%2.2f C, %04.2f hPa\n\r", (sensorTemp.getTemperature()-32)/1.8, sensorTemp.getPressure());
    gOled1.printf("umidade = %2.3f\n\r", (float)umid);
    gOled1.printf("luminosidade = %2.3f\r", (float)ldr);
    gOled1.display();
}

// Verifica a senha que o usuario digitou
void VerificaSenha() {
    char atual[10];
    if(bt.readable()) {
        bt.scanf("%s", atual);
        if (strcmp(senha, atual)) {
            bt.printf("\n\rSenha Incorreta\n\r");
        } else {
            bt.printf("\n\rAlarme desativado\n\r");
            auth = 1;
        }   
    }
}

// Exibe o menu quando o usuario estiver logado
void ImprimeMenu() {
    bt.printf("O que deseja fazer?\r");
    bt.printf("L ou l - Luminosidade\r");
    bt.printf("U ou u - Umidade da planta\r");
    bt.printf("T ou t - Temperatura e pressao\r");
    bt.printf("M ou m - Mudar a senha\r");
    bt.printf("R ou r - Regar a planta\r");
    bt.printf("S ou s - Sair e ativa alarme\n\r");
}

// Inicia o portal da estufa, quando o usuario estiver logado
void Autorizado() {
    bt.printf("-----------------------------\n\r");
    bt.printf("Bem-vindo ao portal da estufa\n\r");
    ImprimeMenu();
    bt.printf("-----------------------------\n\r");
    
    while(auth) {
     
        MostrarOled();
        
        verificaLuz();
        
        verificaAgua();
     
        if (bt.readable()) {
            key = bt.getc();
            switch(key) {
                case 'l':
                case 'L':
                    bt.printf("luminosidade = %2.3f\n\r", (float)ldr);
                    ImprimeMenu();
                    break;
                case 'u':
                case 'U':
                    bt.printf("umidade = %2.3f\r", (float)umid);
                    bt.printf("Quanto menor, mais umido\n\r");
                    ImprimeMenu();
                    break;
                case 't':
                case 'T':
                    bt.printf("%2.2f C, %04.2f hPa\n\r", (sensorTemp.getTemperature()-32)/1.8, sensorTemp.getPressure());
                    ImprimeMenu();
                    break;
                case 'm':
                case 'M':
                    bt.printf("Digite a nova senha(max 10 letras):\n\r");
                    bt.scanf("%s", senha);
                    bt.printf("Senha alterada!\n\r");
                    ImprimeMenu();
                    break;
                case 'r':
                case 'R':
                    bt.printf("Regando...\n\r");
                    bomba.write(1.0f);
                    wait_ms(500);
                    bomba.write(0.0f);
                    ImprimeMenu();
                    break;
                case 's':
                case 'S': 
                    auth = 0;
                    bt.printf("Alarme ativado!\n\r");
                    break;
            }
        }
        wait(1);
    }
    
}

// -------------- MAIN ---------------

int main() {  

    // Limpa o display
    gOled1.clearDisplay(); 
    gOled1.display();
    
    // Desloga usuarios
    auth = 0;
        
    // Define velocidade da UART
    bt.baud(9600);

    // Inicia RFID
    RfChip.PCD_Init();
    
    bomba.period_ms(10);
    bomba.write(0.0f);
    
    bt.printf("\r--------------------------\r");
    bt.printf("Estufa inteligente ativada\r");
    bt.printf("Identifique-se...\r");
    bt.printf("Passe seu cartao ou digite a senha:\n\r");
    wait(1);
        
    while(1) {
        
        if (auth) {
            Autorizado();
            bt.printf("Identifique-se...\r");
            bt.printf("Passe seu cartao ou digite a senha:\n\r"); 
            continue;
        }
        
        MostrarOled();
        
        verifica = 1;
        move = 0;
        
        verificaPos();
        
        verificaLuz();
        
        verificaAgua();
        
        VerificaSenha();

        // Look for new cards
        if ( ! RfChip.PICC_IsNewCardPresent()) {
            wait_ms(500);
            continue;
        }

        // Select one of the cards
        if ( ! RfChip.PICC_ReadCardSerial()) {
            wait_ms(500);
            continue;
        }

        verifica = 0;
        Toque();

        // Print Card UID
        bt.printf("Card UID: ");
        for (uint8_t i = 0; i < RfChip.uid.size; i++) {
            bt.printf(" %X02", RfChip.uid.uidByte[i]);
        }
        bt.printf("\n\rAlarme desativado\n\r");
        // Usuario autenticado
        auth = 1;

        wait_ms(500);
        
    }

}